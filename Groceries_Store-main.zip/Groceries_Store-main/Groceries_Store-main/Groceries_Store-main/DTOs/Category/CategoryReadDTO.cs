﻿namespace Group4_Project.DTOs
{
    public class CategoryReadDTO
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
    }
}
