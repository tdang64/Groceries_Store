﻿namespace Group4_Project.DTOs
{
    public class CategoryUpdateDTO
    {
        public string Name { get; set; } = string.Empty;
    }
}
