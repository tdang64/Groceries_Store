﻿namespace Group4_Project.DTOs
{
    public class CategoryCreateDTO
    {
        public string Name { get; set; } = string.Empty;
    }
}
