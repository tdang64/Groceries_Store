﻿namespace Group4_Project.DTOs
{
    public class SupplierCreateDTO
    {
        public string Name { get; set; } = string.Empty;
        public string Contact { get; set; } = string.Empty;
    }
}
